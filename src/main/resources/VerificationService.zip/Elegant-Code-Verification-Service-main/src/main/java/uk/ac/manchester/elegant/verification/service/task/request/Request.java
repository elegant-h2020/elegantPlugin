package uk.ac.manchester.elegant.verification.service.task.request;

/**
 * This interface represents a code verification request with any tool.
 */
public interface Request {
}
